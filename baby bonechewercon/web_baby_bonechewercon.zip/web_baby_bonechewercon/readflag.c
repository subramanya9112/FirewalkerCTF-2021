int main()
{
    setuid(0);
    system("cat /root/flag");
}